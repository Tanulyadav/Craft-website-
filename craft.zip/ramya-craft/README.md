# Ramya Craft 🏺

**A full-stack e-commerce website for a handmade home-decor brand — with retail shopping cart, checkout, and a dedicated bulk/wholesale trade portal.**

![Next.js](https://img.shields.io/badge/Next.js_16-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript_5-3178C6?style=flat-square&logo=typescript&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS_4-06B6D4?style=flat-square&logo=tailwindcss&logoColor=white)
![Prisma](https://img.shields.io/badge/Prisma-2D3748?style=flat-square&logo=prisma&logoColor=white)
![React](https://img.shields.io/badge/React_19-61DAFB?style=flat-square&logo=react&logoColor=black)

Ramya Craft is a single-page storefront inspired by artisan decor brands. Customers can browse a handcrafted catalog, search & filter products, inspect details in a quick-view dialog, manage a persistent shopping cart, and check out with stock-aware order creation. A dedicated **Bulk Trade** section lets boutiques and retailers submit wholesale inquiries (category, quantity slabs, custom requirements) that are persisted via a dedicated API.

---

## ✨ Features

### Storefront
- 🛍️ **Product catalog** — 14 handcrafted products across 8 categories with AI-generated product photography
- 🔎 **Live search, category filters & sorting** — debounced search, category chips, featured/price/rating sorts
- 👁️ **Quick-view product dialog** — image, materials, dimensions, artisan story, quantity stepper
- 🛒 **Persistent cart** — database-backed cart tied to a browser session (survives refresh), quantity management, free-shipping progress bar (free over ₹1,999)
- 💳 **Checkout flow** — validated customer form, order creation with stock decrement, order confirmation with ID
- 📱 **Fully responsive** — mobile-first layout down to 320px, sticky header, sheet-style cart & mobile menu

### Bulk Trade / Wholesale
- 🏭 **Wholesale portal** — tiered pricing, white-label packaging, export documentation & worldwide shipping highlights
- 📮 **Bulk inquiry form** — category & quantity-slab selectors with server-side validation, persisted to the database

### Craftsmanship
- 🎨 **Artisan brand storytelling** — craft/heritage section with stats, customer testimonials, newsletter block
- 🌅 **Warm artisan design system** — terracotta & sand palette, Playfair Display typography, Framer Motion reveals

---

## 🖼️ Preview

![Ramya Craft hero](public/images/hero.png)

| Shop | Bulk Trade |
| --- | --- |
| ![Product grid](public/images/products/vaseset.png) | ![Bulk trade](public/images/bulk.png) |

---

## 🛠️ Tech Stack

| Layer | Technology |
| --- | --- |
| Framework | **Next.js 16** (App Router) + **React 19** |
| Language | **TypeScript 5** (strict) |
| Styling | **Tailwind CSS 4** + **shadcn/ui** (New York) |
| State | **Zustand** (cart, dialogs, filters) |
| Database | **SQLite** via **Prisma ORM** |
| Animation | **Framer Motion** |
| Icons | **Lucide React** |

---

## 🚀 Getting Started

### Prerequisites
- **Node.js 18.18+** (or [Bun](https://bun.sh))
- npm (bundled with Node) — used below; bun/pnpm work too

### 1. Install dependencies

```bash
npm install
```

### 2. Set up the database

The project uses a file-based SQLite database — **no external database or `.env` file is required.**

```bash
# create the schema (db/custom.db)
npm run db:push

# load the 14-product demo catalog
npm run db:seed
```

### 3. Run the dev server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 📜 Available Scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Start the development server on port 3000 |
| `npm run build` | Create a production build |
| `npm run start` | Serve the production build |
| `npm run lint` | Run ESLint |
| `npm run db:push` | Push the Prisma schema to SQLite |
| `npm run db:seed` | Seed the demo product catalog |
| `npm run db:generate` | Regenerate the Prisma client |

---

## 🗄️ Data Model

```
Product    — name, slug, category, price, compareAt, stock, rating, badges…
CartItem   — session-scoped cart lines (unique per session + product)
Order      — customer details, totals, shipping
OrderItem  — order line items (price snapshot)
Inquiry    — bulk/wholesale leads (company, category, quantity slab…)
```

## 🔌 API Routes

| Method | Route | Description |
| --- | --- | --- |
| `GET` | `/api/products` | List products (filter by category, search, sort) |
| `GET`/`POST` | `/api/cart` | Read / add cart items for the current session |
| `PATCH`/`DELETE` | `/api/cart` | Update quantity / remove a cart item |
| `POST` | `/api/orders` | Create an order from the cart (validates stock) |
| `POST` | `/api/inquiries` | Submit a bulk-trade inquiry |

---

## 📁 Project Structure

```
src/
├── app/
│   ├── api/            # products, cart, orders, inquiries route handlers
│   ├── layout.tsx      # metadata & fonts
│   ├── page.tsx        # single-page storefront
│   └── globals.css     # terracotta/sand design tokens
├── components/
│   ├── shop/           # header, hero, catalog, cart, checkout, bulk trade…
│   └── ui/             # shadcn/ui primitives
├── hooks/              # toast + mobile detection hooks
└── lib/
    ├── db.ts           # Prisma client singleton
    ├── store.ts        # Zustand store (cart, dialogs, filters)
    └── types.ts        # shared types
prisma/
├── schema.prisma       # data model
└── seed.ts             # demo catalog seeder
public/images/          # AI-generated product & hero photography
```

---

## 🔭 Roadmap

- [ ] User authentication (NextAuth) with order history
- [ ] Payment gateway integration (Razorpay/Stripe)
- [ ] Admin dashboard for products & inquiries
- [ ] Image upload pipeline for products

---

> All product photography on this site was AI-generated for demonstration purposes. Ramya Craft is a fictional demo brand.
