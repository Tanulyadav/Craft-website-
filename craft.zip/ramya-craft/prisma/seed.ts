import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const products = [
  {
    name: "Hand-Carved Sheesham Elephant",
    slug: "hand-carved-sheesham-elephant",
    category: "Figurines",
    description:
      "A majestic elephant figurine hand-carved from solid sheesham wood and finished with hand-painted folk motifs. Every piece is unique — carved by artisans in Saharanpur over 3 days.",
    story:
      "Carved by master artisan Ramcharan ji, whose family has sculpted sheesham wood for four generations.",
    price: 1899,
    compareAt: 2499,
    image: "/images/products/elephant.png",
    material: "Sheesham wood, non-toxic paints",
    dimensions: "H 22 × W 30 × D 12 cm",
    badge: "Bestseller",
    rating: 4.9,
    reviewCount: 214,
    stock: 42,
    featured: true,
    bestseller: true,
  },
  {
    name: "Boho Macramé Wall Hanging",
    slug: "boho-macrame-wall-hanging",
    category: "Wall Decor",
    description:
      "Hand-knotted from 100% natural cotton cord on a seasoned wooden dowel. This statement macramé brings warmth and texture to any wall — living rooms, bedrooms or entryways.",
    story:
      "Knotted by a women's cooperative in Jodhpur, each piece takes a full day of mindful knotting.",
    price: 1299,
    compareAt: 1699,
    image: "/images/products/macrame.png",
    material: "Natural cotton cord, teak dowel",
    dimensions: "W 60 × L 85 cm",
    badge: "Handmade",
    rating: 4.8,
    reviewCount: 168,
    stock: 65,
    featured: true,
    bestseller: false,
  },
  {
    name: "Carved Jharokha Wall Mirror",
    slug: "carved-jharokha-wall-mirror",
    category: "Wall Decor",
    description:
      "Inspired by the palace windows of Rajasthan, this arched jharokha mirror is hand-carved from mango wood with a distressed finish that adds old-world charm to modern homes.",
    story:
      "Each jharokha passes through 11 artisans — from rough carving to the final antique polish.",
    price: 4499,
    compareAt: 5599,
    image: "/images/products/mirror.png",
    material: "Mango wood, glass mirror",
    dimensions: "H 90 × W 45 cm",
    badge: "Heritage Craft",
    rating: 4.9,
    reviewCount: 96,
    stock: 18,
    featured: true,
    bestseller: false,
  },
  {
    name: "Terracotta Vase Duo",
    slug: "terracotta-vase-duo",
    category: "Vases & Planters",
    description:
      "A pair of wheel-thrown terracotta vases with rustic texture and hand-painted geometric bands. Perfect for dried stems, pampas or simply as sculptural objects.",
    story:
      "Thrown and painted by potters in Khurja, the pottery town of India, and kiln-fired twice.",
    price: 999,
    compareAt: null,
    image: "/images/products/vaseset.png",
    material: "Terracotta clay, natural pigment",
    dimensions: "H 28 cm & H 20 cm (Set of 2)",
    badge: null,
    rating: 4.7,
    reviewCount: 143,
    stock: 80,
    featured: true,
    bestseller: false,
  },
  {
    name: "Ceramic Planter Trio with Stands",
    slug: "ceramic-planter-trio-stands",
    category: "Vases & Planters",
    description:
      "Three glazed ceramic planters in gradated sizes, each paired with a solid wood stand. A ready-made green corner for your living room or balcony.",
    story:
      "Glazed in small batches — no two glazes swirl exactly the same way.",
    price: 2199,
    compareAt: 2799,
    image: "/images/products/planters.png",
    material: "Glazed ceramic, sheesham stand",
    dimensions: "Ø 14 / 18 / 22 cm (Set of 3)",
    badge: "Bestseller",
    rating: 4.8,
    reviewCount: 187,
    stock: 54,
    featured: false,
    bestseller: true,
  },
  {
    name: "Hand-Painted Dinner Plate Set",
    slug: "hand-painted-dinner-plate-set",
    category: "Tableware",
    description:
      "Four stoneware dinner plates hand-painted with folk florals in rust and indigo. Food-safe, microwave-safe and dishwasher-friendly — craft you can actually use daily.",
    story:
      "Painted freehand by studio potters in Khurja — patterns flow from memory, not stencils.",
    price: 2499,
    compareAt: 3199,
    image: "/images/products/plates.png",
    material: "Glazed stoneware",
    dimensions: "Ø 26 cm (Set of 4)",
    badge: "Food Safe",
    rating: 4.8,
    reviewCount: 121,
    stock: 47,
    featured: true,
    bestseller: false,
  },
  {
    name: "Mango Wood Serving Tray with Brass Inlay",
    slug: "mango-wood-serving-tray-brass",
    category: "Tableware",
    description:
      "Serve chai in style. A generous mango wood tray inlaid with brass wire borders and solid brass handles — equal parts functional and decorative.",
    story:
      "Brass wire is hammered in groove-by-groove by brassworkers in Moradabad.",
    price: 1599,
    compareAt: null,
    image: "/images/products/tray.png",
    material: "Mango wood, solid brass inlay",
    dimensions: "L 45 × W 30 cm",
    badge: null,
    rating: 4.7,
    reviewCount: 88,
    stock: 61,
    featured: false,
    bestseller: false,
  },
  {
    name: "Bamboo Rattan Pendant Lamp",
    slug: "bamboo-rattan-pendant-lamp",
    category: "Lighting",
    description:
      "Hand-woven bamboo pendant shade that casts a beautiful dappled glow. Fits standard E27 holders and looks stunning over dining tables and kitchen islands.",
    story:
      "Woven by bamboo craftspeople in Assam using sustainably harvested bamboo.",
    price: 1899,
    compareAt: 2399,
    image: "/images/products/pendant.png",
    material: "Natural bamboo cane",
    dimensions: "Ø 40 × H 30 cm",
    badge: "Eco Craft",
    rating: 4.9,
    reviewCount: 176,
    stock: 39,
    featured: true,
    bestseller: true,
  },
  {
    name: "Hammered Brass Candle Holders (Set of 3)",
    slug: "hammered-brass-candle-holders",
    category: "Brass & Metal",
    description:
      "Three heights of warm hammered brass to cluster on your dining table or mantel. The antique finish deepens beautifully with age.",
    story:
      "Each holder is shaped from a solid brass block and hammered by hand — over 2,000 strikes per piece.",
    price: 2199,
    compareAt: 2699,
    image: "/images/products/candleholders.png",
    material: "Solid brass, antique finish",
    dimensions: "H 12 / 18 / 24 cm (Set of 3)",
    badge: null,
    rating: 4.8,
    reviewCount: 94,
    stock: 33,
    featured: false,
    bestseller: true,
  },
  {
    name: "Block Print Cushion Covers (Set of 5)",
    slug: "block-print-cushion-covers",
    category: "Textiles",
    description:
      "Five cotton cushion covers printed with hand-carved wooden blocks in rust and earthy neutrals. An instant, affordable room refresh with hidden zippers and piped edges.",
    story:
      "Block printed in Bagru, where each colour is a separate block and a separate day of drying.",
    price: 1499,
    compareAt: 1999,
    image: "/images/products/cushions.png",
    material: "100% cotton canvas",
    dimensions: "45 × 45 cm (Set of 5, covers only)",
    badge: "Handmade",
    rating: 4.6,
    reviewCount: 203,
    stock: 120,
    featured: false,
    bestseller: false,
  },
  {
    name: "Braided Jute Table Runner",
    slug: "braided-jute-table-runner",
    category: "Textiles",
    description:
      "A chunky braided jute runner with hand-knotted tassels that grounds any dining table. Naturally stain-resistant and endlessly textural.",
    story: "Braided from jute fibre sourced directly from farmers in West Bengal.",
    price: 899,
    compareAt: null,
    image: "/images/products/runner.png",
    material: "Natural jute fibre",
    dimensions: "L 180 × W 33 cm",
    badge: null,
    rating: 4.7,
    reviewCount: 76,
    stock: 95,
    featured: false,
    bestseller: false,
  },
  {
    name: "Seagrass Storage Baskets (Set of 3)",
    slug: "seagrass-storage-baskets-set-3",
    category: "Storage & Baskets",
    description:
      "Graduated woven seagrass baskets with sturdy handles — for throws, toys, plants or laundry. The organizing hero every home needs, beautiful enough to leave out.",
    story:
      "Coiled and stitched by artisan families in Bihar over 2 days per set.",
    price: 1799,
    compareAt: 2299,
    image: "/images/products/baskets.png",
    material: "Seagrass, cotton stitch",
    dimensions: "Ø 30 / 36 / 42 cm (Set of 3)",
    badge: "Bestseller",
    rating: 4.8,
    reviewCount: 259,
    stock: 74,
    featured: true,
    bestseller: true,
  },
  {
    name: "Rattan Arched Wall Shelf",
    slug: "rattan-arched-wall-shelf",
    category: "Storage & Baskets",
    description:
      "A two-tier cane shelf with a soft arched top — perfect for displaying plants, ceramics or a growing book collection. Comes with hidden mounting hardware.",
    story:
      "Cane is steam-bent by hand and laced without a single nail by Assamese cane workers.",
    price: 2899,
    compareAt: 3499,
    image: "/images/products/shelf.png",
    material: "Natural cane, mango wood frame",
    dimensions: "H 75 × W 50 × D 16 cm",
    badge: "New",
    rating: 4.8,
    reviewCount: 41,
    stock: 26,
    featured: false,
    bestseller: false,
  },
  {
    name: "Antique Brass Vase with Engraving",
    slug: "antique-brass-vase-engraving",
    category: "Brass & Metal",
    description:
      "A hammered brass vase with fine hand-engraved bands and an antiqued patina. Holds dried stems beautifully — pampas, bunny tails or eucalyptus.",
    story:
      "Engraved freehand with a chisel by the hereditary engravers of Moradabad.",
    price: 2699,
    compareAt: null,
    image: "/images/products/brassvase.png",
    material: "Solid brass, antique patina",
    dimensions: "H 34 cm",
    badge: "Heritage Craft",
    rating: 4.9,
    reviewCount: 67,
    stock: 22,
    featured: false,
    bestseller: false,
  },
];

async function main() {
  console.log("Seeding Ramya Craft catalog...");
  await prisma.cartItem.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.product.deleteMany();

  for (const p of products) {
    await prisma.product.create({ data: p });
  }

  console.log(`Seeded ${products.length} products.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
