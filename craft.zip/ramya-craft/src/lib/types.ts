export type Product = {
  id: string;
  name: string;
  slug: string;
  category: string;
  description: string;
  story: string | null;
  price: number;
  compareAt: number | null;
  image: string;
  material: string;
  dimensions: string;
  badge: string | null;
  rating: number;
  reviewCount: number;
  stock: number;
  featured: boolean;
  bestseller: boolean;
};

export type CartItem = {
  id: string;
  quantity: number;
  product: {
    id: string;
    name: string;
    slug: string;
    price: number;
    image: string;
    category: string;
    stock: number;
  };
};

export type CartSummary = {
  subtotal: number;
  shipping: number;
  total: number;
  count: number;
};

export const FREE_SHIPPING_THRESHOLD = 1999;
export const SHIPPING_FEE = 149;

export const formatINR = (n: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);
