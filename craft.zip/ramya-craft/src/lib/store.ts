"use client";

import { create } from "zustand";
import type { CartItem, CartSummary, Product } from "@/lib/types";

const EMPTY_SUMMARY: CartSummary = {
  subtotal: 0,
  shipping: 0,
  total: 0,
  count: 0,
};

/**
 * FIFO queue for cart mutations.
 * Cart responses carry a full snapshot of the cart — running mutations
 * sequentially guarantees each snapshot is applied on top of the previous
 * one, even when several "Add to Cart" buttons are clicked in quick
 * succession across different product cards.
 */
let cartMutation: Promise<unknown> = Promise.resolve();
function enqueueCartMutation<T>(task: () => Promise<T>): Promise<T> {
  const next = cartMutation.then(task, task);
  cartMutation = next.catch(() => {});
  return next;
}

interface ShopState {
  sessionId: string;
  initialized: boolean;
  items: CartItem[];
  summary: CartSummary;
  cartOpen: boolean;
  cartBusy: boolean;
  quickViewProduct: Product | null;
  quickViewOpen: boolean;
  checkoutOpen: boolean;
  shopSearch: string;
  activeCategory: string;
  searchFocusTick: number;
  init: () => void;
  fetchCart: () => Promise<void>;
  addToCart: (productId: string, quantity?: number) => Promise<boolean>;
  addToCartImpl: (productId: string, quantity?: number) => Promise<boolean>;
  updateQty: (itemId: string, quantity: number) => Promise<void>;
  updateQtyImpl: (itemId: string, quantity: number) => Promise<void>;
  removeItem: (itemId: string) => Promise<void>;
  removeItemImpl: (itemId: string) => Promise<void>;
  clearCartLocal: () => void;
  setCartOpen: (open: boolean) => void;
  setQuickView: (product: Product | null) => void;
  setQuickViewOpen: (open: boolean) => void;
  setCheckoutOpen: (open: boolean) => void;
  setShopSearch: (value: string) => void;
  setActiveCategory: (value: string) => void;
  requestSearchFocus: () => void;
}

export const useShopStore = create<ShopState>()((set, get) => ({
  sessionId: "",
  initialized: false,
  items: [],
  summary: EMPTY_SUMMARY,
  cartOpen: false,
  cartBusy: false,
  quickViewProduct: null,
  quickViewOpen: false,
  checkoutOpen: false,
  shopSearch: "",
  activeCategory: "All",
  searchFocusTick: 0,

  init: () => {
    if (get().initialized) return;
    let sessionId = "";
    try {
      sessionId = localStorage.getItem("ramdez-session") ?? "";
      if (!sessionId) {
        sessionId =
          typeof crypto !== "undefined" && "randomUUID" in crypto
            ? crypto.randomUUID()
            : `s-${Date.now()}-${Math.random().toString(36).slice(2)}`;
        localStorage.setItem("ramdez-session", sessionId);
      }
    } catch {
      sessionId = `s-${Date.now()}`;
    }
    set({ sessionId, initialized: true });
    void get().fetchCart();
  },

  fetchCart: async () => {
    const { sessionId } = get();
    if (!sessionId) return;
    try {
      const res = await fetch(`/api/cart?sessionId=${sessionId}`);
      if (!res.ok) return;
      const data = (await res.json()) as {
        items: CartItem[];
        summary: CartSummary;
      };
      set({ items: data.items, summary: data.summary });
    } catch {
      // silent — cart is non-critical on first load
    }
  },

  addToCart: (productId, quantity = 1) =>
    enqueueCartMutation(() => get().addToCartImpl(productId, quantity)),

  addToCartImpl: async (productId, quantity = 1) => {
    const { sessionId } = get();
    if (!sessionId) return false;
    set({ cartBusy: true });
    try {
      const res = await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, productId, quantity }),
      });
      if (!res.ok) return false;
      const data = (await res.json()) as {
        items: CartItem[];
        summary: CartSummary;
      };
      set({ items: data.items, summary: data.summary });
      return true;
    } catch {
      return false;
    } finally {
      set({ cartBusy: false });
    }
  },

  updateQty: (itemId, quantity) =>
    enqueueCartMutation(() => get().updateQtyImpl(itemId, quantity)),

  updateQtyImpl: async (itemId, quantity) => {
    const { sessionId } = get();
    set({ cartBusy: true });
    try {
      const res = await fetch("/api/cart", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, itemId, quantity }),
      });
      if (res.ok) {
        const data = (await res.json()) as {
          items: CartItem[];
          summary: CartSummary;
        };
        set({ items: data.items, summary: data.summary });
      }
    } finally {
      set({ cartBusy: false });
    }
  },

  removeItem: (itemId) =>
    enqueueCartMutation(() => get().removeItemImpl(itemId)),

  removeItemImpl: async (itemId) => {
    const { sessionId } = get();
    set({ cartBusy: true });
    try {
      const res = await fetch(
        `/api/cart?sessionId=${sessionId}&itemId=${itemId}`,
        { method: "DELETE" }
      );
      if (res.ok) {
        const data = (await res.json()) as {
          items: CartItem[];
          summary: CartSummary;
        };
        set({ items: data.items, summary: data.summary });
      }
    } finally {
      set({ cartBusy: false });
    }
  },

  clearCartLocal: () => set({ items: [], summary: EMPTY_SUMMARY }),

  setCartOpen: (open) => set({ cartOpen: open }),
  setQuickView: (product) => set({ quickViewProduct: product }),
  setQuickViewOpen: (open) => set({ quickViewOpen: open }),
  setCheckoutOpen: (open) => set({ checkoutOpen: open }),
  setShopSearch: (value) => set({ shopSearch: value }),
  setActiveCategory: (value) => set({ activeCategory: value }),
  requestSearchFocus: () =>
    set((s) => ({ searchFocusTick: s.searchFocusTick + 1 })),
}));
