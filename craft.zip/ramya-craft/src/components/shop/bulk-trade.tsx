"use client";

import { useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  BadgePercent,
  Building2,
  FileCheck2,
  Loader2,
  Mail,
  PackageCheck,
  Send,
  Ship,
  User,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { SectionHeading } from "./section-heading";

const BENEFITS = [
  {
    icon: BadgePercent,
    title: "Tiered wholesale pricing",
    text: "Up to 45% off retail at 500+ units — transparent slabs at 50, 100, 250 & 500 pieces per SKU.",
  },
  {
    icon: PackageCheck,
    title: "White-label & custom packaging",
    text: "Your brand, our craft. Custom labels, gift boxes and inserts with low setup costs.",
  },
  {
    icon: FileCheck2,
    title: "Export-ready documentation",
    text: "Commercial invoice, certificate of origin, FSSAI/EPCH papers — we handle the paperwork.",
  },
  {
    icon: Ship,
    title: "Worldwide shipping",
    text: "Sea & air freight to 40+ countries with consolidation and door-to-door quotes.",
  },
];

const CATEGORIES = [
  "Wall Decor",
  "Vases & Planters",
  "Tableware",
  "Lighting",
  "Textiles",
  "Storage & Baskets",
  "Brass & Metal",
  "Figurines",
  "Mixed / Multiple categories",
];

const QUANTITY_SLABS = [
  "50 – 100 units",
  "100 – 250 units",
  "250 – 500 units",
  "500+ units",
];

export function BulkTrade() {
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    category: "",
    quantity: "",
    message: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const set = (key: keyof typeof form) => (value: string) =>
    setForm((f) => ({ ...f, [key]: value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({
          title: "Could not submit inquiry",
          description: data.error ?? "Please review the form and try again.",
          variant: "destructive",
        });
        return;
      }
      setSubmitted(true);
      toast({
        title: "Inquiry received 🤝",
        description: data.message,
      });
    } catch {
      toast({
        title: "Network error",
        description: "Please check your connection and try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section
      id="bulk"
      className="scroll-mt-28 bg-secondary/50 py-14 md:py-20"
      aria-label="Bulk and wholesale trade"
    >
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <SectionHeading
          eyebrow="Bulk Trade & Wholesale"
          title="Partner With Our Artisans"
          subtitle="Boutiques, hotels, interior studios and global retailers — source authentic handmade decor directly from the makers, at wholesale rates."
        />

        <div className="grid items-start gap-8 lg:grid-cols-2 lg:gap-12">
          {/* Left: benefits + image */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.5 }}
            className="flex min-w-0 flex-col gap-5"
          >
            <div className="relative aspect-[16/9] overflow-hidden rounded-2xl shadow-md">
              <Image
                src="/images/bulk.png"
                alt="Ramya Craft warehouse with handmade decor packed in crates for bulk export"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
              <div className="absolute bottom-3 left-3 rounded-lg bg-stone-900/75 px-3 py-1.5 text-xs font-medium text-white backdrop-blur">
                MOQ from just 50 pieces per design
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {BENEFITS.map((b) => (
                <div
                  key={b.title}
                  className="rounded-xl border bg-card p-4 shadow-sm"
                >
                  <div className="mb-2 flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                    <b.icon className="h-5 w-5 text-primary" aria-hidden />
                  </div>
                  <h3 className="text-sm font-semibold">{b.title}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {b.text}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: inquiry form */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.5 }}
          >
            <div className="min-w-0 rounded-2xl border bg-card p-5 shadow-md sm:p-6 md:p-8">
              {submitted ? (
                <div className="flex flex-col items-center gap-4 py-10 text-center">
                  <div className="rounded-full bg-emerald-100 p-4">
                    <FileCheck2 className="h-10 w-10 text-emerald-600" aria-hidden />
                  </div>
                  <h3 className="font-display text-2xl font-bold">
                    Inquiry received!
                  </h3>
                  <p className="max-w-sm text-sm text-muted-foreground">
                    Our bulk trade team will email you the wholesale catalogue,
                    price list and samples policy within 24 hours.
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSubmitted(false);
                      setForm({
                        name: "",
                        company: "",
                        email: "",
                        phone: "",
                        category: "",
                        quantity: "",
                        message: "",
                      });
                    }}
                  >
                    Submit another inquiry
                  </Button>
                </div>
              ) : (
                <form onSubmit={submit} className="flex flex-col gap-4" noValidate={false}>
                  <h3 className="font-display text-xl font-bold">
                    Get the Wholesale Catalogue
                  </h3>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="grid gap-1.5">
                      <Label htmlFor="bq-name">
                        <User className="mr-1 inline h-3.5 w-3.5 text-primary" aria-hidden />
                        Your name *
                      </Label>
                      <Input
                        id="bq-name"
                        required
                        value={form.name}
                        onChange={(e) => set("name")(e.target.value)}
                        placeholder="Aarav Sharma"
                      />
                    </div>
                    <div className="grid gap-1.5">
                      <Label htmlFor="bq-company">
                        <Building2 className="mr-1 inline h-3.5 w-3.5 text-primary" aria-hidden />
                        Company / store
                      </Label>
                      <Input
                        id="bq-company"
                        value={form.company}
                        onChange={(e) => set("company")(e.target.value)}
                        placeholder="Terra Home Pvt. Ltd."
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="grid gap-1.5">
                      <Label htmlFor="bq-email">
                        <Mail className="mr-1 inline h-3.5 w-3.5 text-primary" aria-hidden />
                        Business email *
                      </Label>
                      <Input
                        id="bq-email"
                        type="email"
                        required
                        value={form.email}
                        onChange={(e) => set("email")(e.target.value)}
                        placeholder="buy@yourstore.com"
                      />
                    </div>
                    <div className="grid gap-1.5">
                      <Label htmlFor="bq-phone">Phone / WhatsApp</Label>
                      <Input
                        id="bq-phone"
                        type="tel"
                        value={form.phone}
                        onChange={(e) => set("phone")(e.target.value)}
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="grid gap-1.5">
                      <Label>Product category *</Label>
                      <Select
                        value={form.category}
                        onValueChange={set("category")}
                        required
                      >
                        <SelectTrigger aria-label="Product category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((c) => (
                            <SelectItem key={c} value={c}>
                              {c}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-1.5">
                      <Label>Estimated quantity *</Label>
                      <Select
                        value={form.quantity}
                        onValueChange={set("quantity")}
                        required
                      >
                        <SelectTrigger aria-label="Estimated quantity">
                          <SelectValue placeholder="Select quantity" />
                        </SelectTrigger>
                        <SelectContent>
                          {QUANTITY_SLABS.map((q) => (
                            <SelectItem key={q} value={q}>
                              {q}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid gap-1.5">
                    <Label htmlFor="bq-message">
                      Anything else? (custom designs, packaging, timelines)
                    </Label>
                    <Textarea
                      id="bq-message"
                      rows={3}
                      value={form.message}
                      onChange={(e) => set("message")(e.target.value)}
                      placeholder="We're looking for 200 terracotta vases with our label for a Diwali collection…"
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="h-12 w-full text-sm sm:text-base"
                    disabled={submitting}
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Sending…
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" /> Request Wholesale Pricing
                      </>
                    )}
                  </Button>
                  <p className="text-center text-xs text-muted-foreground">
                    Response within 24 hours · Free samples on first order
                  </p>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
