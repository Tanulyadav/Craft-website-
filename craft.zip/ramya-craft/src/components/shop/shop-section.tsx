"use client";

import { useEffect, useRef, useState } from "react";
import { PackageSearch, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useShopStore } from "@/lib/store";
import { ProductCard, ProductCardSkeleton } from "./product-card";
import { SectionHeading } from "./section-heading";
import type { Product } from "@/lib/types";

const SORT_OPTIONS = [
  { value: "featured", label: "Featured" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "rating", label: "Top Rated" },
];

export function ShopSection() {
  const shopSearch = useShopStore((s) => s.shopSearch);
  const setShopSearch = useShopStore((s) => s.setShopSearch);
  const activeCategory = useShopStore((s) => s.activeCategory);
  const setActiveCategory = useShopStore((s) => s.setActiveCategory);
  const searchFocusTick = useShopStore((s) => s.searchFocusTick);

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState("featured");
  const searchRef = useRef<HTMLInputElement>(null);

  // Focus search when header search icon is tapped
  useEffect(() => {
    if (searchFocusTick > 0) {
      document
        .getElementById("shop")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
      setTimeout(() => searchRef.current?.focus(), 450);
    }
  }, [searchFocusTick]);

  // Fetch products with filters (debounced)
  useEffect(() => {
    const controller = new AbortController();
    const timer = setTimeout(
      async () => {
        setLoading(true);
        try {
          const params = new URLSearchParams({ sort });
          if (activeCategory && activeCategory !== "All") {
            params.set("category", activeCategory);
          }
          if (shopSearch) params.set("search", shopSearch);
          const res = await fetch(`/api/products?${params.toString()}`, {
            signal: controller.signal,
          });
          const data = await res.json();
          setProducts(data.products ?? []);
        } catch {
          /* aborted */
        } finally {
          setLoading(false);
        }
      },
      shopSearch ? 300 : 0
    );
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [activeCategory, shopSearch, sort]);

  // Load category list once
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/products?limit=100");
        const data = await res.json();
        setCategories(data.categories ?? []);
      } catch {
        /* noop */
      }
    })();
  }, []);

  const resetFilters = () => {
    setShopSearch("");
    setActiveCategory("All");
    setSort("featured");
  };

  const chips = ["All", ...categories];

  return (
    <section id="shop" className="scroll-mt-28 py-14 md:py-20" aria-label="Shop all products">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <SectionHeading
          eyebrow="The Marketplace"
          title="Shop All Handmade"
          subtitle="Browse the full Ramya Craft catalogue — every piece one-of-a-kind, every purchase supports an artisan family."
        />

        {/* Toolbar */}
        <div className="mb-6 flex flex-col gap-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <svg
                aria-hidden
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
              <Input
                ref={searchRef}
                type="search"
                value={shopSearch}
                onChange={(e) => setShopSearch(e.target.value)}
                placeholder="Search for vases, macramé, brass…"
                className="pl-9"
                aria-label="Search the catalogue"
              />
            </div>
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="w-full sm:w-52" aria-label="Sort products">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                {SORT_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Category chips */}
          <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
            {chips.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setActiveCategory(c)}
                aria-pressed={activeCategory === c}
                className={`shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                  activeCategory === c
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground/80 hover:border-primary/40 hover:bg-secondary"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-6 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center gap-4 rounded-xl border border-dashed py-16 text-center">
            <PackageSearch className="h-12 w-12 text-muted-foreground" aria-hidden />
            <div>
              <p className="text-lg font-semibold">No products found</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Try a different search term or browse all categories.
              </p>
            </div>
            <Button variant="outline" onClick={resetFilters}>
              <RotateCcw className="mr-2 h-4 w-4" /> Reset filters
            </Button>
          </div>
        ) : (
          <>
            <p className="mb-4 text-sm text-muted-foreground" aria-live="polite">
              Showing {products.length} {products.length === 1 ? "piece" : "pieces"}
              {activeCategory !== "All" ? ` in ${activeCategory}` : ""}
              {shopSearch ? ` for “${shopSearch}”` : ""}
            </p>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-6 lg:grid-cols-4">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
