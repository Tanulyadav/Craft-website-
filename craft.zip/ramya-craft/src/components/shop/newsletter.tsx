"use client";

import { useState } from "react";
import { Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export function Newsletter() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);

  const subscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }
    setBusy(true);
    // Simulated subscription — no backend needed for the demo
    await new Promise((r) => setTimeout(r, 600));
    setBusy(false);
    setEmail("");
    toast({
      title: "You're on the list! ✉️",
      description: "Watch your inbox for new collections and artisan stories.",
    });
  };

  return (
    <section className="bg-primary py-12 md:py-16" aria-label="Newsletter signup">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-6 px-4 text-center md:px-8">
        <div className="rounded-full bg-white/10 p-3">
          <Mail className="h-6 w-6 text-amber-200" aria-hidden />
        </div>
        <div>
          <h2 className="font-display text-2xl font-bold text-primary-foreground md:text-3xl">
            Get 10% Off Your First Order
          </h2>
          <p className="mt-2 max-w-xl text-sm text-primary-foreground/80 md:text-base">
            Join 12,000+ decor lovers for new collections, artisan stories and
            subscriber-only bulk offers.
          </p>
        </div>
        <form
          onSubmit={subscribe}
          className="flex w-full max-w-md flex-col gap-3 sm:flex-row"
        >
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            aria-label="Email address"
            className="h-12 border-white/30 bg-white/10 text-primary-foreground placeholder:text-primary-foreground/60"
          />
          <Button
            type="submit"
            size="lg"
            variant="secondary"
            className="h-12 shrink-0 bg-white text-primary hover:bg-amber-100"
            disabled={busy}
          >
            {busy ? "Joining…" : "Subscribe"}
          </Button>
        </form>
      </div>
    </section>
  );
}
