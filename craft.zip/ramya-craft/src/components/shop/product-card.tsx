"use client";

import { useState } from "react";
import Image from "next/image";
import { Heart, Loader2, Plus, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useShopStore } from "@/lib/store";
import { formatINR, type Product } from "@/lib/types";

function RatingStars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`Rated ${rating} out of 5`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-3.5 w-3.5 ${
            i < Math.round(rating)
              ? "fill-amber-500 text-amber-500"
              : "fill-stone-200 text-stone-200"
          }`}
        />
      ))}
    </div>
  );
}

export function ProductCard({ product }: { product: Product }) {
  const addToCart = useShopStore((s) => s.addToCart);
  const setQuickView = useShopStore((s) => s.setQuickView);
  const setQuickViewOpen = useShopStore((s) => s.setQuickViewOpen);
  const { toast } = useToast();
  const [wishlisted, setWishlisted] = useState(false);
  const [adding, setAdding] = useState(false);

  const handleAdd = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setAdding(true);
    const ok = await addToCart(product.id, 1);
    setAdding(false);
    toast({
      title: ok ? "Added to cart" : "Something went wrong",
      description: ok
        ? `${product.name} has been added to your cart.`
        : "Please try again in a moment.",
      variant: ok ? "default" : "destructive",
    });
  };

  const openQuickView = () => {
    setQuickView(product);
    setQuickViewOpen(true);
  };

  const discount =
    product.compareAt && product.compareAt > product.price
      ? Math.round(((product.compareAt - product.price) / product.compareAt) * 100)
      : 0;

  return (
    <article
      className="group flex h-full cursor-pointer flex-col overflow-hidden rounded-xl border bg-card shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-lg focus-within:ring-2 focus-within:ring-ring"
      onClick={openQuickView}
      role="button"
      tabIndex={0}
      aria-label={`View ${product.name}`}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openQuickView();
        }
      }}
    >
      <div className="relative aspect-square overflow-hidden bg-muted">
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {product.badge && (
            <Badge className="bg-primary text-primary-foreground hover:bg-primary">
              {product.badge}
            </Badge>
          )}
          {discount > 0 && (
            <Badge variant="secondary" className="bg-amber-100 text-amber-900">
              {discount}% off
            </Badge>
          )}
        </div>
        <button
          type="button"
          aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
          className="absolute right-3 top-3 rounded-full bg-white/90 p-2 shadow-sm transition-transform hover:scale-110 active:scale-95"
          onClick={(e) => {
            e.stopPropagation();
            setWishlisted((w) => !w);
          }}
        >
          <Heart
            className={`h-4 w-4 ${
              wishlisted ? "fill-red-500 text-red-500" : "text-stone-600"
            }`}
          />
        </button>
        <div className="absolute inset-x-3 bottom-3 translate-y-2 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 max-md:translate-y-0 max-md:opacity-100">
          <Button
            size="sm"
            className="w-full"
            disabled={adding}
            onClick={handleAdd}
          >
            {adding ? (
              <>
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Adding…
              </>
            ) : (
              <>
                <Plus className="mr-1.5 h-4 w-4" /> Add to Cart
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-1 p-4">
        <p className="text-xs uppercase tracking-wide text-muted-foreground">
          {product.category}
        </p>
        <h3 className="line-clamp-2 font-medium leading-snug text-foreground">
          {product.name}
        </h3>
        <div className="flex items-center gap-1.5">
          <RatingStars rating={product.rating} />
          <span className="text-xs text-muted-foreground">
            ({product.reviewCount})
          </span>
        </div>
        <div className="mt-auto flex items-baseline gap-2 pt-1.5">
          <span className="text-lg font-semibold text-primary">
            {formatINR(product.price)}
          </span>
          {product.compareAt && product.compareAt > product.price && (
            <span className="text-sm text-muted-foreground line-through">
              {formatINR(product.compareAt)}
            </span>
          )}
        </div>
      </div>
    </article>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="flex h-full flex-col overflow-hidden rounded-xl border bg-card">
      <div className="aspect-square animate-pulse bg-muted" />
      <div className="flex flex-col gap-2 p-4">
        <div className="h-3 w-16 animate-pulse rounded bg-muted" />
        <div className="h-4 w-3/4 animate-pulse rounded bg-muted" />
        <div className="h-3 w-24 animate-pulse rounded bg-muted" />
        <div className="h-5 w-20 animate-pulse rounded bg-muted" />
      </div>
    </div>
  );
}

export { RatingStars };
