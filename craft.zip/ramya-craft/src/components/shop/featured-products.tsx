"use client";

import { useEffect, useState } from "react";
import { SectionHeading } from "./section-heading";
import { ProductCard, ProductCardSkeleton } from "./product-card";
import type { Product } from "@/lib/types";

export function FeaturedProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const res = await fetch("/api/products?featured=true&limit=4");
        const data = await res.json();
        if (active) setProducts(data.products ?? []);
      } catch {
        if (active) setProducts([]);
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  return (
    <section className="bg-secondary/50 py-14 md:py-20" aria-label="Featured products">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <SectionHeading
          eyebrow="Loved by Homes"
          title="Bestsellers & New Arrivals"
          subtitle="Handpicked pieces our customers can’t stop ordering — each one signed by the artisan who made it."
        />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => <ProductCardSkeleton key={i} />)
            : products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </section>
  );
}
