"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { Globe, HandHeart, Leaf, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "./section-heading";
import { scrollToId } from "./shop-provider";

const STATS = [
  { value: "24+", label: "Years of craft" },
  { value: "2,000+", label: "Artisan families" },
  { value: "40+", label: "Countries shipped" },
  { value: "100%", label: "Handmade, always" },
];

const VALUES = [
  {
    icon: HandHeart,
    title: "Fair trade, first",
    text: "Artisans earn 2.5× the local average wage and receive advance payments for raw materials.",
  },
  {
    icon: Leaf,
    title: "Sustainably sourced",
    text: "FSC-certified wood, natural dyes, recycled brass and plastic-free packaging as standard.",
  },
  {
    icon: ShieldCheck,
    title: "Quality, guaranteed",
    text: "Every piece passes a 12-point inspection. If it isn't perfect, it doesn't leave the workshop.",
  },
  {
    icon: Globe,
    title: "Craft that travels",
    text: "From Saharanpur to Stockholm — we've shipped handmade warmth to 40+ countries.",
  },
];

export function CraftSection() {
  return (
    <section id="craft" className="scroll-mt-28 py-14 md:py-20" aria-label="Our craft and story">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-14">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative aspect-[4/3] overflow-hidden rounded-2xl shadow-lg">
              <Image
                src="/images/craft.png"
                alt="An artisan hand-carving a wooden piece in the Ramya Craft workshop"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-5 -right-3 rounded-2xl border bg-card p-4 shadow-lg md:-right-6">
              <p className="font-display text-3xl font-bold text-primary">2.5×</p>
              <p className="text-xs text-muted-foreground">
                average wage paid
                <br />
                to our artisans
              </p>
            </div>
          </motion.div>

          {/* Text */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6 }}
          >
            <SectionHeading
              align="left"
              eyebrow="Our Craft"
              title="From Our Hands to Your Home"
              subtitle="Ramya Craft began in 2001 as a single wood-carving workshop in Saharanpur. Today we partner with 2,000+ artisan families across India — potters, weavers, brass-workers and bamboo craftsmen — to bring honest, handmade decor to homes and businesses worldwide."
            />
            <div className="grid gap-4 sm:grid-cols-2">
              {VALUES.map((v) => (
                <div key={v.title} className="flex gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <v.icon className="h-5 w-5 text-primary" aria-hidden />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold">{v.title}</h3>
                    <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                      {v.text}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <Button className="mt-7" size="lg" onClick={() => scrollToId("shop")}>
              Explore the Collection
            </Button>
          </motion.div>
        </div>

        {/* Stats band */}
        <div className="mt-16 grid grid-cols-2 gap-4 rounded-2xl bg-primary px-6 py-8 text-primary-foreground md:grid-cols-4 md:py-10">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <p className="font-display text-3xl font-bold md:text-4xl">{s.value}</p>
              <p className="mt-1 text-xs opacity-80 md:text-sm">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
