"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { SectionHeading } from "./section-heading";
import { useShopStore } from "@/lib/store";
import { scrollToId } from "./shop-provider";

const COLLECTIONS = [
  { name: "Wall Decor", image: "/images/products/macrame.png" },
  { name: "Vases & Planters", image: "/images/products/vaseset.png" },
  { name: "Tableware", image: "/images/products/plates.png" },
  { name: "Lighting", image: "/images/products/pendant.png" },
  { name: "Textiles", image: "/images/products/cushions.png" },
  { name: "Storage & Baskets", image: "/images/products/baskets.png" },
  { name: "Brass & Metal", image: "/images/products/brassvase.png" },
  { name: "Figurines", image: "/images/products/elephant.png" },
];

export function CategoryStrip() {
  const setActiveCategory = useShopStore((s) => s.setActiveCategory);

  const pick = (name: string) => {
    setActiveCategory(name);
    scrollToId("shop");
  };

  return (
    <section id="collections" className="scroll-mt-28 py-14 md:py-20" aria-label="Shop by collection">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <SectionHeading
          eyebrow="Collections"
          title="Shop by Category"
          subtitle="Every category is a different craft — wood carving, pottery, weaving, brass work and more."
        />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:gap-6 lg:grid-cols-4">
          {COLLECTIONS.map((c, i) => (
            <motion.button
              key={c.name}
              type="button"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.4, delay: (i % 4) * 0.08 }}
              onClick={() => pick(c.name)}
              className="group flex flex-col items-center gap-3 rounded-xl border bg-card p-5 text-center shadow-sm transition-all hover:-translate-y-1 hover:border-primary/40 hover:shadow-md"
            >
              <div className="relative h-24 w-24 overflow-hidden rounded-full border-2 border-secondary ring-2 ring-transparent transition-all group-hover:ring-primary/30 md:h-28 md:w-28">
                <Image
                  src={c.image}
                  alt={`${c.name} collection`}
                  fill
                  sizes="120px"
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <span className="text-sm font-semibold md:text-base">{c.name}</span>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
}
