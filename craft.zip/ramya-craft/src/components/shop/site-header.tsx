"use client";

import { useState } from "react";
import { Menu, Search, ShoppingBag, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { useShopStore } from "@/lib/store";
import { scrollToId } from "./shop-provider";

const NAV_LINKS = [
  { label: "Shop", id: "shop" },
  { label: "Collections", id: "collections" },
  { label: "Bulk Trade", id: "bulk" },
  { label: "Our Craft", id: "craft" },
  { label: "Reviews", id: "reviews" },
];

export function SiteHeader() {
  const cartCount = useShopStore((s) => s.summary.count);
  const setCartOpen = useShopStore((s) => s.setCartOpen);
  const setShopSearch = useShopStore((s) => s.setShopSearch);
  const requestSearchFocus = useShopStore((s) => s.requestSearchFocus);
  const [menuOpen, setMenuOpen] = useState(false);

  const go = (id: string) => {
    setMenuOpen(false);
    scrollToId(id);
  };

  const handleSearch = (value: string) => {
    setShopSearch(value);
    if (value.length >= 1) {
      scrollToId("shop");
    }
  };

  return (
    <div className="sticky top-0 z-50">
      {/* Announcement bar */}
      <div className="bg-primary text-primary-foreground">
        <p className="mx-auto flex max-w-7xl items-center justify-center gap-2 px-4 py-1.5 text-center text-xs sm:text-sm">
          <Sparkles className="h-3.5 w-3.5 shrink-0" aria-hidden />
          <span>
            Free shipping over ₹1,999 · Handmade by 2,000+ artisans ·{" "}
            <button
              type="button"
              onClick={() => go("bulk")}
              className="underline underline-offset-2 hover:opacity-80"
            >
              Bulk &amp; trade enquiries welcome
            </button>
          </span>
        </p>
      </div>

      {/* Main header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:gap-6">
          {/* Mobile menu */}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                aria-label="Open menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72">
              <SheetHeader>
                <SheetTitle className="font-display text-xl text-primary">
                  Ramya Craft
                </SheetTitle>
                <SheetDescription className="sr-only">
                  Navigation menu for Ramya Craft handmade home decor store
                </SheetDescription>
              </SheetHeader>
              <nav className="mt-2 flex flex-col gap-1 px-4" aria-label="Mobile navigation">
                {NAV_LINKS.map((link) => (
                  <button
                    key={link.id}
                    type="button"
                    onClick={() => go(link.id)}
                    className="rounded-lg px-3 py-2.5 text-left text-base font-medium hover:bg-secondary"
                  >
                    {link.label}
                  </button>
                ))}
              </nav>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="flex items-center gap-2.5"
            aria-label="Ramya Craft — back to top"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary font-display text-lg font-bold text-primary-foreground">
              R
            </span>
            <span className="font-display text-xl font-bold tracking-tight text-foreground">
              Ramya <span className="text-primary">Craft</span>
            </span>
          </button>

          {/* Desktop nav */}
          <nav className="hidden flex-1 items-center justify-center gap-1 md:flex" aria-label="Main navigation">
            {NAV_LINKS.map((link) => (
              <button
                key={link.id}
                type="button"
                onClick={() => go(link.id)}
                className="rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:bg-secondary hover:text-foreground"
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Search (desktop) */}
          <div className="relative ml-auto hidden w-56 lg:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input
              type="search"
              placeholder="Search handmade decor…"
              className="pl-9"
              aria-label="Search products"
              onChange={(e) => handleSearch(e.target.value)}
            />
          </div>

          {/* Mobile search */}
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto lg:hidden"
            aria-label="Search products"
            onClick={() => {
              scrollToId("shop");
              requestSearchFocus();
            }}
          >
            <Search className="h-5 w-5" />
          </Button>

          {/* Cart */}
          <Button
            variant="outline"
            size="icon"
            className="relative shrink-0"
            aria-label={`Open cart, ${cartCount} items`}
            onClick={() => setCartOpen(true)}
          >
            <ShoppingBag className="h-5 w-5" />
            {cartCount > 0 && (
              <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[11px] font-semibold text-primary-foreground">
                {cartCount}
              </span>
            )}
          </Button>
        </div>
      </header>
    </div>
  );
}
