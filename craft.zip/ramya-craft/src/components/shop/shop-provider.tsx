"use client";

import { useEffect } from "react";
import { useShopStore } from "@/lib/store";

export function ShopProvider({ children }: { children: React.ReactNode }) {
  const init = useShopStore((s) => s.init);

  useEffect(() => {
    init();
  }, [init]);

  return <>{children}</>;
}

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (el) {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}
