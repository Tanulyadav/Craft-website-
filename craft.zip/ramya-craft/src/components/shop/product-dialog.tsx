"use client";

import { useState } from "react";
import Image from "next/image";
import {
  Handshake,
  Loader2,
  Minus,
  Package,
  Plus,
  Ruler,
  ShoppingBag,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useShopStore } from "@/lib/store";
import { formatINR, type Product } from "@/lib/types";
import { RatingStars } from "./product-card";
import { scrollToId } from "./shop-provider";

export function ProductDialog() {
  const product = useShopStore((s) => s.quickViewProduct);
  const open = useShopStore((s) => s.quickViewOpen);
  const setOpen = useShopStore((s) => s.setQuickViewOpen);
  const setQuickView = useShopStore((s) => s.setQuickView);

  return (
    <Dialog
      open={open && !!product}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) setQuickView(null);
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto p-0 sm:max-w-3xl custom-scrollbar">
        {product && <ProductDialogBody key={product.id} product={product} />}
      </DialogContent>
    </Dialog>
  );
}

function ProductDialogBody({ product }: { product: Product }) {
  const setOpen = useShopStore((s) => s.setQuickViewOpen);
  const setQuickView = useShopStore((s) => s.setQuickView);
  const addToCart = useShopStore((s) => s.addToCart);
  const { toast } = useToast();
  const [qty, setQty] = useState(1);
  const [adding, setAdding] = useState(false);

  const handleAdd = async () => {
    setAdding(true);
    const ok = await addToCart(product.id, qty);
    setAdding(false);
    toast({
      title: ok ? "Added to cart" : "Something went wrong",
      description: ok
        ? `${qty} × ${product.name} added to your cart.`
        : "Please try again in a moment.",
      variant: ok ? "default" : "destructive",
    });
    if (ok) {
      setOpen(false);
      setQuickView(null);
    }
  };

  return (
    <div className="grid md:grid-cols-2">
      {/* Image */}
      <div className="relative aspect-square bg-muted md:aspect-auto md:min-h-[480px]">
              <Image
                src={product.image}
                alt={product.name}
                fill
                sizes="(max-width: 768px) 100vw, 384px"
                className="object-cover md:rounded-l-lg"
                priority
              />
              {product.badge && (
                <Badge className="absolute left-4 top-4 bg-primary text-primary-foreground hover:bg-primary">
                  {product.badge}
                </Badge>
              )}
            </div>

            {/* Details */}
            <div className="flex flex-col gap-4 p-6 md:overflow-y-auto custom-scrollbar">
              <DialogHeader className="space-y-2 text-left">
                <p className="text-xs uppercase tracking-widest text-muted-foreground">
                  {product.category}
                </p>
                <DialogTitle className="font-display text-2xl leading-snug">
                  {product.name}
                </DialogTitle>
                <DialogDescription asChild>
                  <div className="flex items-center gap-2">
                    <RatingStars rating={product.rating} />
                    <span className="text-sm text-muted-foreground">
                      {product.rating} · {product.reviewCount} reviews
                    </span>
                  </div>
                </DialogDescription>
              </DialogHeader>

              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-primary">
                  {formatINR(product.price)}
                </span>
                {product.compareAt && product.compareAt > product.price && (
                  <span className="text-lg text-muted-foreground line-through">
                    {formatINR(product.compareAt)}
                  </span>
                )}
              </div>

              <p className="text-sm leading-relaxed text-muted-foreground">
                {product.description}
              </p>

              {product.story && (
                <blockquote className="rounded-lg border-l-4 border-primary/50 bg-secondary/60 p-3 text-sm italic text-foreground/80">
                  “{product.story}”
                </blockquote>
              )}

              <Separator />

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-start gap-2">
                  <Package className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
                  <span className="text-muted-foreground">{product.material}</span>
                </div>
                <div className="flex items-start gap-2">
                  <Ruler className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
                  <span className="text-muted-foreground">{product.dimensions}</span>
                </div>
              </div>

              <p className="text-sm">
                {product.stock > 10 ? (
                  <span className="text-emerald-700">● In stock — ships in 2–4 days</span>
                ) : (
                  <span className="text-amber-700">
                    ● Only {product.stock} left — made in small batches
                  </span>
                )}
              </p>

              {/* Quantity + Add to cart */}
              <div className="mt-auto flex flex-col gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium">Quantity</span>
                  <div className="flex items-center rounded-lg border">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-9 w-9"
                      aria-label="Decrease quantity"
                      onClick={() => setQty((q) => Math.max(1, q - 1))}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="w-10 text-center text-sm font-semibold" aria-live="polite">
                      {qty}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-9 w-9"
                      aria-label="Increase quantity"
                      onClick={() => setQty((q) => Math.min(product.stock, q + 1))}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <span className="ml-auto text-sm text-muted-foreground">
                    Total: {formatINR(product.price * qty)}
                  </span>
                </div>

                <Button
                  size="lg"
                  className="h-12 text-base"
                  disabled={adding}
                  onClick={handleAdd}
                >
                  {adding ? (
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  ) : (
                    <ShoppingBag className="mr-2 h-5 w-5" />
                  )}
                  Add to Cart
                </Button>

                <button
                  type="button"
                  onClick={() => {
                    setOpen(false);
                    setQuickView(null);
                    setTimeout(() => scrollToId("bulk"), 200);
                  }}
                  className="inline-flex items-center justify-center gap-2 rounded-lg border border-primary/40 bg-primary/5 px-4 py-3 text-sm font-medium text-primary transition-colors hover:bg-primary/10"
                >
                  <Handshake className="h-4 w-4" aria-hidden />
                  Need 50+ units? Get wholesale rates →
                </button>
              </div>
            </div>
  </div>
  );
}
