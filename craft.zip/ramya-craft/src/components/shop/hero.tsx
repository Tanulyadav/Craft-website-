"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight, Handshake, ShieldCheck, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { scrollToId } from "./shop-provider";

export function Hero() {
  return (
    <section aria-label="Hero" className="relative">
      <div className="relative min-h-[520px] w-full overflow-hidden md:min-h-[620px]">
        <Image
          src="/images/hero.png"
          alt="A warm living room styled with handmade Ramya Craft home decor — rattan pendant lamp, terracotta vases and macramé wall hanging"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-stone-900/80 via-stone-900/55 to-stone-900/15" />

        <div className="relative mx-auto flex min-h-[520px] max-w-7xl flex-col justify-center px-4 py-20 md:min-h-[620px] md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="max-w-2xl"
          >
            <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium text-amber-100 backdrop-blur">
              <span aria-hidden>✦</span> Handcrafted in India since 2001
            </p>
            <h1 className="font-display text-4xl font-bold leading-tight text-white sm:text-5xl md:text-6xl">
              Home Decor, Made by Hand.
              <span className="block text-amber-200">Made to Be Loved.</span>
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-stone-200 sm:text-lg">
              Ramya Craft brings you one-of-a-kind vases, wall art, tableware,
              lighting and textiles — crafted by 2,000+ artisan families. Buy one
              for your home, or a thousand for your business.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button
                size="lg"
                className="h-12 px-7 text-base"
                onClick={() => scrollToId("shop")}
              >
                Shop the Collection
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-12 border-white/40 bg-white/10 px-7 text-base text-white backdrop-blur hover:bg-white/20 hover:text-white"
                onClick={() => scrollToId("bulk")}
              >
                <Handshake className="mr-2 h-4 w-4" />
                Bulk &amp; Trade Enquiries
              </Button>
            </div>

            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-sm text-stone-200">
              <span className="inline-flex items-center gap-2">
                <Truck className="h-4 w-4 text-amber-300" /> Free shipping over ₹1,999
              </span>
              <span className="inline-flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-amber-300" /> 14-day easy returns
              </span>
              <span className="inline-flex items-center gap-2">
                <Handshake className="h-4 w-4 text-amber-300" /> Fair-trade certified
              </span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
