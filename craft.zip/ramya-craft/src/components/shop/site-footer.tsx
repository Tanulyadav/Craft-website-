"use client";

import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { useShopStore } from "@/lib/store";
import { scrollToId } from "./shop-provider";

const SHOP_LINKS = [
  { label: "Wall Decor", cat: "Wall Decor" },
  { label: "Vases & Planters", cat: "Vases & Planters" },
  { label: "Tableware", cat: "Tableware" },
  { label: "Lighting", cat: "Lighting" },
  { label: "Textiles", cat: "Textiles" },
  { label: "Storage & Baskets", cat: "Storage & Baskets" },
];

const COMPANY_LINKS = [
  { label: "Shop All", id: "shop" },
  { label: "Bulk Trade", id: "bulk" },
  { label: "Our Craft", id: "craft" },
  { label: "Customer Reviews", id: "reviews" },
];

export function SiteFooter() {
  const setActiveCategory = (cat: string) => {
    useShopStore.getState().setActiveCategory(cat);
    scrollToId("shop");
  };

  return (
    <footer
      id="contact"
      className="mt-auto border-t bg-stone-900 text-stone-300 pb-[env(safe-area-inset-bottom)]"
      aria-label="Site footer"
    >
      <div className="mx-auto max-w-7xl px-4 py-12 md:px-8 md:py-16">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary font-display text-lg font-bold text-primary-foreground">
                R
              </span>
              <span className="font-display text-xl font-bold text-white">
                Ramya <span className="text-amber-300">Craft</span>
              </span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-stone-400">
              Handmade home decor crafted by 2,000+ artisan families across
              India. One piece for your home — or a thousand for your business.
            </p>
            <div className="mt-4 flex gap-2">
              {["Instagram", "Facebook", "Pinterest"].map((s) => (
                <span
                  key={s}
                  className="cursor-pointer rounded-md border border-stone-700 px-2.5 py-1 text-xs text-stone-400 transition-colors hover:border-amber-300/50 hover:text-amber-200"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Shop */}
          <nav aria-label="Footer shop links">
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-white">
              Shop
            </h3>
            <ul className="flex flex-col gap-2.5 text-sm">
              {SHOP_LINKS.map((l) => (
                <li key={l.cat}>
                  <button
                    type="button"
                    className="transition-colors hover:text-amber-200"
                    onClick={() => setActiveCategory(l.cat)}
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Company */}
          <nav aria-label="Footer company links">
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-white">
              Company
            </h3>
            <ul className="flex flex-col gap-2.5 text-sm">
              {COMPANY_LINKS.map((l) => (
                <li key={l.id}>
                  <button
                    type="button"
                    className="transition-colors hover:text-amber-200"
                    onClick={() => scrollToId(l.id)}
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-white">
              Contact Us
            </h3>
            <ul className="flex flex-col gap-3 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" aria-hidden />
                <span>
                  Ramya Craft Pvt. Ltd., Civil Lines,
                  <br />
                  Saharanpur, UP 247001, India
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 shrink-0 text-amber-300" aria-hidden />
                <a href="tel:+919876543210" className="hover:text-amber-200">
                  +91 98765 43210
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 shrink-0 text-amber-300" aria-hidden />
                <a href="mailto:hello@ramdezcraft.com" className="hover:text-amber-200">
                  hello@ramdezcraft.com
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Clock className="h-4 w-4 shrink-0 text-amber-300" aria-hidden />
                <span>Mon–Sat, 9 AM – 7 PM IST</span>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-8 bg-stone-800" />

        <div className="flex flex-col items-center justify-between gap-3 text-xs text-stone-500 md:flex-row">
          <p>© {new Date().getFullYear()} Ramya Craft. All rights reserved. Handmade in India.</p>
          <p className="flex items-center gap-1.5">
            Secure payments · UPI · Cards · COD · GST invoices available
          </p>
        </div>
      </div>
    </footer>
  );
}
