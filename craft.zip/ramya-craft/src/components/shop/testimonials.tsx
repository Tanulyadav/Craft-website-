"use client";

import { motion } from "framer-motion";
import { Quote } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { RatingStars } from "./product-card";
import { SectionHeading } from "./section-heading";

const TESTIMONIALS = [
  {
    quote:
      "The jharokha mirror is even more beautiful in person — our living room completely changed. You can feel the hand-carving in every detail.",
    name: "Meera Kapoor",
    role: "Homeowner · Pune",
    rating: 5,
  },
  {
    quote:
      "We've ordered 300+ units across three bulk drops for our boutique chain. Consistent quality, honest pricing and packaging our customers love unboxing.",
    name: "Arjun Nair",
    role: "Founder, Terra Home · Bulk Buyer",
    rating: 5,
  },
  {
    quote:
      "As a European importer, documentation and timelines matter most. Ramya Craft delivers on both — our third container is already on the water.",
    name: "Sofia Lindqvist",
    role: "Buyer, Nordic Nest · Sweden",
    rating: 5,
  },
];

export function Testimonials() {
  return (
    <section id="reviews" className="scroll-mt-28 py-14 md:py-20" aria-label="Customer reviews">
      <div className="mx-auto max-w-7xl px-4 md:px-8">
        <SectionHeading
          eyebrow="Reviews"
          title="Loved at Home & in Business"
          subtitle="From single pieces for living rooms to container-loads for retail chains — here's what our customers say."
        />
        <div className="grid gap-5 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <motion.figure
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="min-w-0 flex h-full flex-col gap-4 rounded-2xl border bg-card p-5 shadow-sm sm:p-6"
            >
              <Quote className="h-7 w-7 text-primary/40" aria-hidden />
              <blockquote className="flex-1 text-sm leading-relaxed text-foreground/90">
                “{t.quote}”
              </blockquote>
              <figcaption className="flex flex-wrap items-center gap-x-3 gap-y-2 border-t pt-4">
                <Avatar className="h-10 w-10 shrink-0 border">
                  <AvatarFallback className="bg-secondary font-semibold text-primary">
                    {t.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold leading-tight">{t.name}</p>
                  <p className="text-xs leading-tight text-muted-foreground">
                    {t.role}
                  </p>
                </div>
                <div className="ml-auto shrink-0">
                  <RatingStars rating={t.rating} />
                </div>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
