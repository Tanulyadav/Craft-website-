"use client";

import Image from "next/image";
import { Loader2, Minus, Plus, ShoppingBag, Trash2, Truck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { useShopStore } from "@/lib/store";
import { FREE_SHIPPING_THRESHOLD, formatINR } from "@/lib/types";
import { scrollToId } from "./shop-provider";

export function CartSheet() {
  const open = useShopStore((s) => s.cartOpen);
  const setOpen = useShopStore((s) => s.setCartOpen);
  const items = useShopStore((s) => s.items);
  const summary = useShopStore((s) => s.summary);
  const cartBusy = useShopStore((s) => s.cartBusy);
  const updateQty = useShopStore((s) => s.updateQty);
  const removeItem = useShopStore((s) => s.removeItem);
  const setCheckoutOpen = useShopStore((s) => s.setCheckoutOpen);

  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - summary.subtotal);
  const progress = Math.min(100, (summary.subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  const goCheckout = () => {
    setOpen(false);
    setCheckoutOpen(true);
  };

  const continueShopping = () => {
    setOpen(false);
    setTimeout(() => scrollToId("shop"), 200);
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="flex w-full flex-col p-0 sm:max-w-md">
        <SheetHeader className="border-b p-5">
          <SheetTitle className="flex items-center gap-2 text-lg">
            <ShoppingBag className="h-5 w-5 text-primary" aria-hidden />
            Your Cart {summary.count > 0 && `(${summary.count})`}
          </SheetTitle>
          <SheetDescription className="sr-only">
            Review the items in your shopping cart and proceed to checkout.
          </SheetDescription>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="rounded-full bg-secondary p-6">
              <ShoppingBag className="h-10 w-10 text-muted-foreground" aria-hidden />
            </div>
            <div>
              <p className="text-lg font-semibold">Your cart is empty</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Add some handmade warmth to your home.
              </p>
            </div>
            <Button onClick={continueShopping}>Continue Shopping</Button>
          </div>
        ) : (
          <>
            {/* Free shipping progress */}
            <div className="border-b bg-secondary/50 px-5 py-3">
              <div className="mb-2 flex items-center gap-2 text-sm">
                <Truck className="h-4 w-4 text-primary" aria-hidden />
                {remaining > 0 ? (
                  <span>
                    Add <strong>{formatINR(remaining)}</strong> more for{" "}
                    <strong>free shipping</strong>
                  </span>
                ) : (
                  <span className="font-medium text-emerald-700">
                    You&apos;ve unlocked free shipping! 🎉
                  </span>
                )}
              </div>
              <Progress value={progress} className="h-2" aria-label="Free shipping progress" />
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto p-5 custom-scrollbar">
              <ul className="flex flex-col gap-4">
                {items.map((item) => (
                  <li
                    key={item.id}
                    className="flex gap-3 rounded-xl border bg-card p-3"
                  >
                    <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-muted">
                      <Image
                        src={item.product.image}
                        alt={item.product.name}
                        fill
                        sizes="80px"
                        className="object-cover"
                      />
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold leading-snug">
                            {item.product.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {item.product.category}
                          </p>
                        </div>
                        <button
                          type="button"
                          aria-label={`Remove ${item.product.name} from cart`}
                          className="rounded p-1 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                          disabled={cartBusy}
                          onClick={() => removeItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="mt-auto flex items-center justify-between pt-2">
                        <div className="flex items-center rounded-lg border">
                          <button
                            type="button"
                            aria-label="Decrease quantity"
                            className="flex h-7 w-7 items-center justify-center rounded-l-md hover:bg-secondary disabled:opacity-50"
                            disabled={cartBusy}
                            onClick={() => updateQty(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="w-8 text-center text-sm font-semibold">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            aria-label="Increase quantity"
                            className="flex h-7 w-7 items-center justify-center rounded-r-md hover:bg-secondary disabled:opacity-50"
                            disabled={cartBusy || item.quantity >= item.product.stock}
                            onClick={() => updateQty(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <span className="text-sm font-bold text-primary">
                          {formatINR(item.product.price * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            {/* Summary */}
            <div className="border-t bg-background p-5">
              <div className="flex flex-col gap-1.5 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formatINR(summary.subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>
                    {summary.shipping === 0 ? (
                      <span className="font-medium text-emerald-700">FREE</span>
                    ) : (
                      formatINR(summary.shipping)
                    )}
                  </span>
                </div>
                <Separator className="my-1.5" />
                <div className="flex justify-between text-base font-bold">
                  <span>Total</span>
                  <span className="text-primary">{formatINR(summary.total)}</span>
                </div>
              </div>
              <Button
                size="lg"
                className="mt-4 h-12 w-full text-base"
                disabled={cartBusy}
                onClick={goCheckout}
              >
                {cartBusy ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : null}
                Proceed to Checkout
              </Button>
              <p className="mt-2.5 text-center text-xs text-muted-foreground">
                Secure checkout · COD &amp; UPI available · 14-day returns
              </p>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
