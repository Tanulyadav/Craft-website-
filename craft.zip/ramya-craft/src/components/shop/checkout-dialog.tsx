"use client";

import { useEffect, useState } from "react";
import {
  CheckCircle2,
  CreditCard,
  Loader2,
  MapPin,
  PartyPopper,
  User,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useShopStore } from "@/lib/store";
import { formatINR, type CartItem, type CartSummary } from "@/lib/types";

type PlacedOrder = {
  id: string;
  total: number;
  items: { id: string; name: string; quantity: number; price: number }[];
};

const EMPTY_FORM = {
  name: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  postalCode: "",
};

export function CheckoutDialog() {
  const open = useShopStore((s) => s.checkoutOpen);
  const setOpen = useShopStore((s) => s.setCheckoutOpen);
  const items = useShopStore((s) => s.items);
  const summary = useShopStore((s) => s.summary);
  const fetchCart = useShopStore((s) => s.fetchCart);
  const { toast } = useToast();

  const [form, setForm] = useState(EMPTY_FORM);
  const [placing, setPlacing] = useState(false);
  const [placedOrder, setPlacedOrder] = useState<PlacedOrder | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Snapshot cart when dialog opens so it survives the cart clearing
  const [snapshotItems, setSnapshotItems] = useState<CartItem[]>([]);
  const [snapshotSummary, setSnapshotSummary] = useState<CartSummary | null>(null);

  useEffect(() => {
    if (open) {
      setSnapshotItems(items);
      setSnapshotSummary(summary);
      setPlacedOrder(null);
      setErrors({});
    }
  }, [open]);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Full name is required";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Enter a valid email";
    if (!/^[+\d][\d\s-]{7,14}$/.test(form.phone.trim())) e.phone = "Enter a valid phone number";
    if (!form.address.trim()) e.address = "Address is required";
    if (!form.city.trim()) e.city = "City is required";
    if (!/^\d{5,6}$/.test(form.postalCode.trim())) e.postalCode = "Enter a valid PIN code";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const placeOrder = async () => {
    if (!validate()) return;
    const sessionId = useShopStore.getState().sessionId;
    setPlacing(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, ...form }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({
          title: "Could not place order",
          description: data.error ?? "Please try again.",
          variant: "destructive",
        });
        return;
      }
      setPlacedOrder(data.order);
      await fetchCart();
      toast({
        title: "Order confirmed 🎉",
        description: `Order #${data.order.id.slice(-8).toUpperCase()} placed successfully.`,
      });
    } catch {
      toast({
        title: "Network error",
        description: "Please check your connection and try again.",
        variant: "destructive",
      });
    } finally {
      setPlacing(false);
    }
  };

  const set = (key: keyof typeof EMPTY_FORM) => (value: string) =>
    setForm((f) => ({ ...f, [key]: value }));

  const displayItems = placedOrder ? snapshotItems : items;
  const displaySummary = placedOrder && snapshotSummary ? snapshotSummary : summary;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg custom-scrollbar">
        {placedOrder ? (
          /* ---------- Success state ---------- */
          <div className="flex flex-col items-center gap-4 py-6 text-center">
            <div className="rounded-full bg-emerald-100 p-4">
              <CheckCircle2 className="h-12 w-12 text-emerald-600" aria-hidden />
            </div>
            <DialogHeader className="items-center space-y-2 text-center">
              <DialogTitle className="font-display text-2xl">
                Thank you for your order!
              </DialogTitle>
              <DialogDescription>
                We&apos;ve received your order and our artisans are packing it with care.
              </DialogDescription>
            </DialogHeader>
            <div className="w-full rounded-xl border bg-secondary/40 p-4 text-left text-sm">
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">Order ID</span>
                <span className="font-mono font-semibold">
                  #{placedOrder.id.slice(-8).toUpperCase()}
                </span>
              </div>
              <ul className="my-2 flex flex-col gap-1.5 border-b pb-2">
                {placedOrder.items.map((it) => (
                  <li key={it.id} className="flex justify-between gap-2">
                    <span className="truncate">
                      {it.name} × {it.quantity}
                    </span>
                    <span>{formatINR(it.price * it.quantity)}</span>
                  </li>
                ))}
              </ul>
              <div className="flex justify-between font-bold">
                <span>Total paid</span>
                <span className="text-primary">{formatINR(placedOrder.total)}</span>
              </div>
            </div>
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <PartyPopper className="h-4 w-4 text-primary" aria-hidden />
              A confirmation has been sent to your email.
            </p>
            <Button
              size="lg"
              className="mt-2 w-full"
              onClick={() => {
                setOpen(false);
                setForm(EMPTY_FORM);
              }}
            >
              Continue Shopping
            </Button>
          </div>
        ) : (
          /* ---------- Form state ---------- */
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <CreditCard className="h-5 w-5 text-primary" aria-hidden />
                Checkout
              </DialogTitle>
              <DialogDescription>
                {displayItems.length} {displayItems.length === 1 ? "item" : "items"} ·{" "}
                Total {formatINR(displaySummary?.total ?? 0)} (pay on delivery or via UPI)
              </DialogDescription>
            </DialogHeader>

            <div className="mt-2 flex flex-col gap-4">
              <div className="grid gap-1.5">
                <Label htmlFor="co-name" className="flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5 text-primary" aria-hidden /> Full name
                </Label>
                <Input
                  id="co-name"
                  value={form.name}
                  onChange={(e) => set("name")(e.target.value)}
                  placeholder="Aarav Sharma"
                  aria-invalid={!!errors.name}
                />
                {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="co-email">Email</Label>
                  <Input
                    id="co-email"
                    type="email"
                    value={form.email}
                    onChange={(e) => set("email")(e.target.value)}
                    placeholder="you@example.com"
                    aria-invalid={!!errors.email}
                  />
                  {errors.email && (
                    <p className="text-xs text-destructive">{errors.email}</p>
                  )}
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="co-phone">Phone</Label>
                  <Input
                    id="co-phone"
                    type="tel"
                    value={form.phone}
                    onChange={(e) => set("phone")(e.target.value)}
                    placeholder="+91 98765 43210"
                    aria-invalid={!!errors.phone}
                  />
                  {errors.phone && (
                    <p className="text-xs text-destructive">{errors.phone}</p>
                  )}
                </div>
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="co-address" className="flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-primary" aria-hidden /> Delivery address
                </Label>
                <Textarea
                  id="co-address"
                  value={form.address}
                  onChange={(e) => set("address")(e.target.value)}
                  placeholder="Flat / house no, street, landmark"
                  rows={2}
                  aria-invalid={!!errors.address}
                />
                {errors.address && (
                  <p className="text-xs text-destructive">{errors.address}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="co-city">City</Label>
                  <Input
                    id="co-city"
                    value={form.city}
                    onChange={(e) => set("city")(e.target.value)}
                    placeholder="Jaipur"
                    aria-invalid={!!errors.city}
                  />
                  {errors.city && <p className="text-xs text-destructive">{errors.city}</p>}
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="co-pin">PIN code</Label>
                  <Input
                    id="co-pin"
                    inputMode="numeric"
                    value={form.postalCode}
                    onChange={(e) => set("postalCode")(e.target.value)}
                    placeholder="302001"
                    aria-invalid={!!errors.postalCode}
                  />
                  {errors.postalCode && (
                    <p className="text-xs text-destructive">{errors.postalCode}</p>
                  )}
                </div>
              </div>

              <div className="rounded-lg bg-secondary/50 p-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formatINR(displaySummary?.subtotal ?? 0)}</span>
                </div>
                <div className="mt-1 flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>
                    {displaySummary?.shipping === 0 ? "FREE" : formatINR(displaySummary?.shipping ?? 0)}
                  </span>
                </div>
                <div className="mt-1 flex justify-between border-t pt-1.5 font-bold">
                  <span>Total</span>
                  <span className="text-primary">{formatINR(displaySummary?.total ?? 0)}</span>
                </div>
              </div>

              <Button
                size="lg"
                className="h-12 text-base"
                disabled={placing || displayItems.length === 0}
                onClick={placeOrder}
              >
                {placing ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Placing order…
                  </>
                ) : (
                  <>
                    <CreditCard className="mr-2 h-5 w-5" /> Place Order ·{" "}
                    {formatINR(displaySummary?.total ?? 0)}
                  </>
                )}
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
