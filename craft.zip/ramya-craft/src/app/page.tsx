"use client";

import { ShopProvider } from "@/components/shop/shop-provider";
import { SiteHeader } from "@/components/shop/site-header";
import { Hero } from "@/components/shop/hero";
import { CategoryStrip } from "@/components/shop/category-strip";
import { FeaturedProducts } from "@/components/shop/featured-products";
import { ShopSection } from "@/components/shop/shop-section";
import { BulkTrade } from "@/components/shop/bulk-trade";
import { CraftSection } from "@/components/shop/craft-section";
import { Testimonials } from "@/components/shop/testimonials";
import { Newsletter } from "@/components/shop/newsletter";
import { SiteFooter } from "@/components/shop/site-footer";
import { CartSheet } from "@/components/shop/cart-sheet";
import { ProductDialog } from "@/components/shop/product-dialog";
import { CheckoutDialog } from "@/components/shop/checkout-dialog";

export default function Home() {
  return (
    <ShopProvider>
      <div className="flex min-h-screen flex-col">
        <SiteHeader />
        <main className="flex-1">
          <Hero />
          <CategoryStrip />
          <FeaturedProducts />
          <ShopSection />
          <BulkTrade />
          <CraftSection />
          <Testimonials />
          <Newsletter />
        </main>
        <SiteFooter />

        {/* Overlays */}
        <CartSheet />
        <ProductDialog />
        <CheckoutDialog />
      </div>
    </ShopProvider>
  );
}
