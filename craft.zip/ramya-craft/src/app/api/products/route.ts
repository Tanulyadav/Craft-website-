import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category") ?? "";
    const search = searchParams.get("search") ?? "";
    const sort = searchParams.get("sort") ?? "featured";
    const featured = searchParams.get("featured");
    const limit = searchParams.get("limit");

    const where: {
      category?: string;
      featured?: boolean;
    } = {};

    if (category && category !== "All") {
      where.category = category;
    }
    if (featured === "true") {
      where.featured = true;
    }

    let orderBy: Record<string, "asc" | "desc">[] = [{ createdAt: "asc" }];
    if (sort === "price-asc") orderBy = [{ price: "asc" }];
    else if (sort === "price-desc") orderBy = [{ price: "desc" }];
    else if (sort === "rating") orderBy = [{ rating: "desc" }];
    else if (sort === "featured") orderBy = [{ bestseller: "desc" }, { createdAt: "asc" }];

    let products = await db.product.findMany({
      where,
      orderBy,
      ...(limit ? { take: Number(limit) } : {}),
    });

    // Case-insensitive search filtering (SQLite contains is case-sensitive)
    if (search) {
      const q = search.toLowerCase();
      products = products.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }

    const categories = await db.product.findMany({
      select: { category: true },
      distinct: ["category"],
      orderBy: { category: "asc" },
    });

    return NextResponse.json({
      products,
      categories: categories.map((c) => c.category),
      total: products.length,
    });
  } catch (error) {
    console.error("GET /api/products error:", error);
    return NextResponse.json(
      { error: "Failed to fetch products" },
      { status: 500 }
    );
  }
}
