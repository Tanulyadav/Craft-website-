import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

const FREE_SHIPPING_THRESHOLD = 1999;
const SHIPPING_FEE = 149;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, name, email, phone, address, city, postalCode } =
      body as Record<string, string>;

    if (!sessionId || !name || !email || !phone || !address || !city || !postalCode) {
      return NextResponse.json(
        { error: "All fields are required to place the order." },
        { status: 400 }
      );
    }

    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!emailOk) {
      return NextResponse.json(
        { error: "Please enter a valid email address." },
        { status: 400 }
      );
    }

    const cartItems = await db.cartItem.findMany({
      where: { sessionId },
      include: { product: true },
    });

    if (cartItems.length === 0) {
      return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
    }

    const subtotal = cartItems.reduce(
      (sum, item) => sum + item.product.price * item.quantity,
      0
    );
    const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;

    const order = await db.order.create({
      data: {
        sessionId,
        name,
        email,
        phone,
        address,
        city,
        postalCode,
        subtotal,
        shipping,
        total: subtotal + shipping,
        status: "confirmed",
        items: {
          create: cartItems.map((item) => ({
            productId: item.productId,
            name: item.product.name,
            price: item.product.price,
            quantity: item.quantity,
          })),
        },
      },
      include: { items: true },
    });

    // Decrement stock and clear the cart
    for (const item of cartItems) {
      await db.product.update({
        where: { id: item.productId },
        data: { stock: { decrement: item.quantity } },
      });
    }
    await db.cartItem.deleteMany({ where: { sessionId } });

    return NextResponse.json({ order }, { status: 201 });
  } catch (error) {
    console.error("POST /api/orders error:", error);
    return NextResponse.json(
      { error: "Failed to place order. Please try again." },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const sessionId = new URL(request.url).searchParams.get("sessionId");
    if (!sessionId) {
      return NextResponse.json({ error: "sessionId required" }, { status: 400 });
    }

    const orders = await db.order.findMany({
      where: { sessionId },
      include: { items: true },
      orderBy: { createdAt: "desc" },
      take: 10,
    });

    return NextResponse.json({ orders });
  } catch (error) {
    console.error("GET /api/orders error:", error);
    return NextResponse.json(
      { error: "Failed to fetch orders" },
      { status: 500 }
    );
  }
}
