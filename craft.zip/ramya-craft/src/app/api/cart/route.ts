import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

async function getCartPayload(sessionId: string) {
  const items = await db.cartItem.findMany({
    where: { sessionId },
    include: { product: true },
    orderBy: { createdAt: "desc" },
  });

  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  const shipping = subtotal === 0 ? 0 : subtotal >= 1999 ? 0 : 149;

  return {
    items: items.map((item) => ({
      id: item.id,
      quantity: item.quantity,
      product: {
        id: item.product.id,
        name: item.product.name,
        slug: item.product.slug,
        price: item.product.price,
        image: item.product.image,
        category: item.product.category,
        stock: item.product.stock,
      },
    })),
    summary: { subtotal, shipping, total: subtotal + shipping, count },
  };
}

export async function GET(request: NextRequest) {
  try {
    const sessionId = new URL(request.url).searchParams.get("sessionId");
    if (!sessionId) {
      return NextResponse.json({ error: "sessionId required" }, { status: 400 });
    }
    return NextResponse.json(await getCartPayload(sessionId));
  } catch (error) {
    console.error("GET /api/cart error:", error);
    return NextResponse.json({ error: "Failed to load cart" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, productId, quantity } = body as {
      sessionId?: string;
      productId?: string;
      quantity?: number;
    };

    if (!sessionId || !productId) {
      return NextResponse.json(
        { error: "sessionId and productId are required" },
        { status: 400 }
      );
    }

    const product = await db.product.findUnique({ where: { id: productId } });
    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    const qty = Math.max(1, Math.min(quantity ?? 1, product.stock));

    const existing = await db.cartItem.findUnique({
      where: { sessionId_productId: { sessionId, productId } },
    });

    if (existing) {
      await db.cartItem.update({
        where: { id: existing.id },
        data: { quantity: Math.min(existing.quantity + qty, product.stock) },
      });
    } else {
      await db.cartItem.create({
        data: { sessionId, productId, quantity: qty },
      });
    }

    return NextResponse.json(await getCartPayload(sessionId), { status: 201 });
  } catch (error) {
    console.error("POST /api/cart error:", error);
    return NextResponse.json({ error: "Failed to add to cart" }, { status: 500 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, itemId, quantity } = body as {
      sessionId?: string;
      itemId?: string;
      quantity?: number;
    };

    if (!sessionId || !itemId || typeof quantity !== "number") {
      return NextResponse.json(
        { error: "sessionId, itemId and quantity are required" },
        { status: 400 }
      );
    }

    const item = await db.cartItem.findFirst({
      where: { id: itemId, sessionId },
      include: { product: true },
    });

    if (!item) {
      return NextResponse.json({ error: "Cart item not found" }, { status: 404 });
    }

    if (quantity <= 0) {
      await db.cartItem.delete({ where: { id: item.id } });
    } else {
      await db.cartItem.update({
        where: { id: item.id },
        data: { quantity: Math.min(quantity, item.product.stock) },
      });
    }

    return NextResponse.json(await getCartPayload(sessionId));
  } catch (error) {
    console.error("PATCH /api/cart error:", error);
    return NextResponse.json(
      { error: "Failed to update cart" },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get("sessionId");
    const itemId = searchParams.get("itemId");

    if (!sessionId) {
      return NextResponse.json({ error: "sessionId required" }, { status: 400 });
    }

    if (itemId) {
      await db.cartItem.deleteMany({ where: { id: itemId, sessionId } });
    } else {
      await db.cartItem.deleteMany({ where: { sessionId } });
    }

    return NextResponse.json(await getCartPayload(sessionId));
  } catch (error) {
    console.error("DELETE /api/cart error:", error);
    return NextResponse.json(
      { error: "Failed to remove item" },
      { status: 500 }
    );
  }
}
