import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, company, email, phone, category, quantity, message } =
      body as Record<string, string>;

    if (!name || !email || !category || !quantity) {
      return NextResponse.json(
        { error: "Name, email, product category and quantity are required." },
        { status: 400 }
      );
    }

    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!emailOk) {
      return NextResponse.json(
        { error: "Please enter a valid email address." },
        { status: 400 }
      );
    }

    const inquiry = await db.inquiry.create({
      data: {
        name,
        company: company || null,
        email,
        phone: phone || null,
        category,
        quantity,
        message: message || null,
      },
    });

    return NextResponse.json(
      {
        inquiry: { id: inquiry.id },
        message:
          "Thank you! Our bulk trade team will reach out within 24 hours with the wholesale catalogue and pricing.",
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/inquiries error:", error);
    return NextResponse.json(
      { error: "Failed to submit inquiry. Please try again." },
      { status: 500 }
    );
  }
}
