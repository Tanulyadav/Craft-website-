import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Ramya Craft — Handmade Home Decor & Bulk Trade",
  description:
    "Ramya Craft is a handmade home decor brand. Shop artisan-crafted vases, wall decor, tableware, lighting and textiles — or partner with us for bulk & wholesale trade.",
  keywords: [
    "Ramya Craft",
    "handmade home decor",
    "artisan decor",
    "bulk trade",
    "wholesale handicrafts",
    "home decor India",
  ],
  authors: [{ name: "Ramya Craft" }],
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "Ramya Craft — Handmade Home Decor & Bulk Trade",
    description:
      "Handcrafted home decor from 2,000+ artisan families. Retail & bulk trade welcome.",
    siteName: "Ramya Craft",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
